from deepquantum.utils import ptrace
import torch
import torch.nn as nn
from .qconv import QConvXYZ
from .qpool import QPoolXYZ
from .deqconv import DEQConvXYZ
from .deqpool import DEQPoolXYZ


class Q_AEnet(nn.Module):
    def __init__(self, n_qubits):
        super(Q_AEnet, self).__init__()
        self.qconv1 = QConvXYZ(n_qubits)
        self.pool = QPoolXYZ(n_qubits)
        self.depool = DEQPoolXYZ(n_qubits)
        self.deqconv = DEQConvXYZ(n_qubits)
    def forward(self, x, y, n, n_trash):
        x = self.qconv1(x)
        x = self.pool(x)
        x = ptrace(x, n, n_trash)
        de_input = torch.kron(x, y)
        de_out = self.depool(de_input)
        de_out = self.deqconv(de_out)
        return de_out